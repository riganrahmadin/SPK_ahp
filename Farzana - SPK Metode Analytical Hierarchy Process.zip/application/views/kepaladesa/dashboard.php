 <!-- Header -->
    <div class="header  pb-6 bg-gradient-gray"  >
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
               
               
            </div>
            
          </div> 
        </div>
        <?= $this->session->flashdata('msg2') ?>
      </div>
    </div>  

    <div class="container-fluid mt--6">
       <div class="row">
        <div class="col-xl-12 order-xl-1">
           
          <div class="card"> 
            <div class="card-body">
              
              <h1>Selamat Datang di Sistem Pendukung Keputusan Menggunakan Metode Analitycal Hierarchy Process (AHP)</h1>
              <br>
              <p>Metode Analitycal Hierarchy Process (Metode AHP) adalah sebuah metode dalam sistem pendukung kuputusan untuk memecahkan suatu masalah yang sangat komplek serta tidak terstruktur kedalam beberapa bagian komponen didalam susunan hirarki dengan memberi nilai yang subjektif tentang pentingnya bagi variabel secara relatif serta menetapkan variabel yang memiliki prioritas paling tinggi agar mempengaruhi result atau hasil pada masalah tersebut.</p>
            </div>
          </div>
        </div>
             
        </div>
    </div>

 
