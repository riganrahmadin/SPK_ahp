<?php 
class IR_m extends MY_Model
{

  function __construct()
  {
    parent::__construct(); 
    $this->data['table_name'] = 'ir';
  }


  
}

 ?>
